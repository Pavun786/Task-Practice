import logo from './logo.svg';
import './App.css';
import SegmentModel from './SegmentModel';

function App() {
  return (
    <div className="App">
      <SegmentModel/>
    </div>
  );
}

export default App;
